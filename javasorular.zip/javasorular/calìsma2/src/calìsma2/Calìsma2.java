/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package calısma2;
import java.util.Scanner;
/**
 *
 * @author Tuğbanur
 */
public class Calısma2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
        int onlar,birler;
        int dizi[]={47,29,34,12,53,98};
        int dizi2[]=new int[dizi.length];
        for(int i=0;i<dizi.length;i++)
        {
            dizi2[i]=dizi[(dizi.length-i)-1]; //neden ters çevrilmedi???
            onlar=dizi[i]/10;
            birler=dizi[i]-onlar*10;
            System.out.print(birler);
            System.out.print(onlar);
        }
       
    }
    
}
