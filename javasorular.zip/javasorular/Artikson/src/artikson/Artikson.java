/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package artikson;
import java.util.Scanner;
/**
 *
 * @author Tuğbanur
 */
public class Artikson {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
       int sayi=0;
       Scanner s = new Scanner(System.in);
       System.out.println("Dizi boyutunu giriniz:");
       int boyut=s.nextInt();
       int dizi[]=new int[boyut+1];
       System.out.println("Dizi boyutunu giriniz:");
       for(int i=0; i<=boyut; i++)
       {
           dizi[i]=s.nextInt();
       }
       dizi[dizi.length-1]=0;
       System.out.println("Yeni sayı girilecek satır:");
       int satir=s.nextInt();
       System.out.println("Yeni değer:");
       int deger=s.nextInt();
       if(dizi[dizi.length-1]==dizi[satir])
       {
           dizi[dizi.length-1]=dizi[satir];
       }
       else
       {
           dizi[dizi.length-1]=dizi[satir];
           dizi[satir]=deger;
           dizi[dizi.length-1]=dizi[satir+1];
       }
       for(int i=0; i<=boyut; i++)
       {
           System.out.print(dizi[i]+" ");
       }
    }
}
    

