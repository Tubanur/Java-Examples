/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package q1;

import java.util.Scanner;

/**
 *
 * @author serhat
 */
public class Q1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        String sentence ;
        System.out.print("Write the sentence to be reversed recursively:");
        Scanner s=new Scanner(System.in);
        sentence=s.next();
        System.out.println("The reversed sentence is: " + reverse(sentence));
    }
    
    public static String reverse(String sentence)
    {
        if (sentence.isEmpty())
            return sentence;

        return reverse(sentence.substring(1)) + sentence.charAt(0);
    }
    
}
