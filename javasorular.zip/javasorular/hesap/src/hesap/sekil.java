/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hesap;

/**
 *
 * @author Tuğbanur
 */
public class sekil extends boyut {
    void kare()
    {
        System.out.println("Şekil karedir");
    }
    void dortgen()
    {
        System.out.println("Şekil dikdortgendir");
    }
    void cokgen()
    {
        System.out.println("Şekil çokgendir");
    }
}
