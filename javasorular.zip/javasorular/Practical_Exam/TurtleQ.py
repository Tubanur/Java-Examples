import turtle 

ninja = turtle.Turtle()

ninja.speed(10)
a=150

for i in range(36):
    if i>17:
        a=250  
    ninja.pencolor("red")
    ninja.right(120)
    ninja.forward(a)
    ninja.pencolor("blue")
    ninja.left(120)
    ninja.forward(a)    
    
    ninja.penup()
    ninja.setposition(0, 0)
    ninja.pendown()
    
    ninja.right(20)
    

