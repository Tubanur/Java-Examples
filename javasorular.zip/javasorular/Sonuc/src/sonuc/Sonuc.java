/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sonuc;

/**
 *
 * @author Tuğbanur
 */
public class Sonuc {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
       Sekil t1 = new Sekil();
       Sekil t2 = new Sekil();
       t1.en=4.0;
       t1.boy=4.0;
       t1.stil="kare";
       t2.en=5.5;
       t2.boy=4.0;
       t2.stil="dikdörtgen";
       System.out.println("T1 bilgisi:");
       t1.seklimiz();
       t1.goster();
       System.out.println("Alan:"+t1.alan());
       System.out.println("T2 bilgisi:");
       t2.seklimiz();
       t2.goster();
       System.out.println("Alan:"+t2.alan());
    }
    
}
