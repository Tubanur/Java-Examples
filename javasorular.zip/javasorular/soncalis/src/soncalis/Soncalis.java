/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package soncalis;
import java.util.Scanner;
/**
 *
 * @author Tuğbanur
 */
public class Soncalis {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
        int enk,enb;
        Scanner s = new Scanner(System.in);
        int dizi[]=new int[10];
        enb=dizi[0];
        enk=dizi[0];
        for(int i=1;i<10;i++)
        {
            dizi[i]=(1+(int)(Math.random()*10));
            if(i==dizi[0])
            {
                enk=dizi[0];
            }
            System.out.print(dizi[i]+" ");
            if(dizi[i]<enk)
            {
                enk=dizi[i];
            }
            if(dizi[i]>enb)
            {
                enb=dizi[i];
            }
            
        }
        System.out.println();
        System.out.println("en küçük sayı:"+enk+" "+"en büyük sayı:"+enb);
    }
    
}
