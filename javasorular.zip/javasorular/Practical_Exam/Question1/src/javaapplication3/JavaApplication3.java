/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication3;

import java.util.Scanner;

/**
 *
 * @author serhat
 */
public class JavaApplication3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
         int p, q, n, x , y, temp = 0, k = 0;
        Scanner s = new Scanner(System.in);
        System.out.print("Enter number of rows in matrix:");
        p = s.nextInt();
        System.out.print("Enter number of columns in matrix:");
        q = s.nextInt();
        int a[][] = new int[p][q];
        System.out.println("Enter all the elements of matrix:");
        for (int i = 0; i < p; i++) 
        {
            for (int j = 0; j < q; j++) 
            {
                a[i][j] = s.nextInt();
            }
        }
        System.out.println("Given Matrix:");
        for (int i = 0; i < p; i++) 
        {
            for (int j = 0; j < q; j++) 
            {
                System.out.print(a[i][j] + " ");
            }
            System.out.println("");
        }
        
                System.out.println("Enter the row numbers:");
                x = s.nextInt();
                y = s.nextInt();
                for(int i = 0; i < p; i++)
                {
                    temp = a[(x-1)][i];
                    a[x-1][i] = a[y-1][i];
                    a[y-1][i] = temp;
                }
                System.out.println("Matrix after interchanging rows:"+x +" and "+y);
                for (int i = 0; i < p; i++) 
                {
                    for (int j = 0; j < q; j++) 
                    {
                        System.out.print(a[i][j] + " ");
                    }
                System.out.println("");
                }
               
                
        
    }
    
}
