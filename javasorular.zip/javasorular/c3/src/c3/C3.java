/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package c3;

import java.util.Scanner;

/**
 *
 * @author Tuğbanur
 */
public class C3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
        int sayi;
        Scanner s = new Scanner(System.in);
        System.out.println("sayı gir");
        sayi=s.nextInt();
        for(int j=1;j<=sayi;j++)
        {
            for(int i=sayi-j; i>=0; i--)
            {
                System.out.print(" ");

            }
            for(int a=1; a<=(j*2)-1;a++)
            {
                System.out.print("*");
            }
            System.out.println();
            
        }
        for(int j=sayi-1;j>=0;j--)
        {
            for(int i=0; i<=sayi-j; i++)
            {
                System.out.print(" ");

            }
            for(int a=(j*2)-2; a>=0;a--)
            {
                System.out.print("*");
            }
            System.out.println();
            
        }
        
        
    }
    
}
