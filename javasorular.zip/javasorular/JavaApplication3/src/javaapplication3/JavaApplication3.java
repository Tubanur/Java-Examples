/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication3;
import java.util.Scanner;
/**
 *
 * @author Tuğbanur
 */
public class JavaApplication3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args)
    {
         int number, newrow, newnum;
         Scanner s = new Scanner (System.in);
         System.out.println("Enter dimesion of array:");
         number=s.nextInt();
         int array [] = new int[number+1];
         System.out.println("Enter" + number + "items of array:");
         for(int i=1; i<array.length; i++)
         {
             array[i]=s.nextInt();
         }
         System.out.println("Enter the row that new number wil be placed in:");
         newnum=s.nextInt();
         if(newnum>number)
            System.out.println("The number entered can not be greater than the array size");
        else
        {
         System.out.printf("Enter new item of array:");
            newnum=s.nextInt();
            for(int i=0;i<newrow-1;i++)
            {
                    array[i]=array[i+1];                    
            }
        array[newrow-1]=newnum;
        for(int i=0;i<array.length;i++){
            System.out.println(array[i]);
    }
    
    }   
}

