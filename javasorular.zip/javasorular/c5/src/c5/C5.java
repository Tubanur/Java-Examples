/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package c5;
import java.util.*;
/**
 *
 * @author Tuğbanur
 */
public class C5 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
        int N,M;
        Scanner s = new Scanner(System.in);
        System.out.println("Dizinin satır boyutu girin");
        N=s.nextInt();
        System.out.println("Dizinin sütun boyutu girin");
        M=s.nextInt();
        int a [][]=new int [N][M];
        for(int i=0;i<N;i++)
        {
            for(int j=0;j<M;j++)
            {
                a[i][j]=(1+(int)(Math.random()*10));
                System.out.print(a[i][j]);
            }
            System.out.println();
        }
    }

}
