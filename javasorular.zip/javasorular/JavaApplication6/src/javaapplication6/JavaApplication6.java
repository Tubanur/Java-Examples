/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication6;
import java.util.Scanner;
/**
 *
 * @author Tuğbanur
 */
public class JavaApplication6 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args)
    {
        int a,b;
        char karakter;
        Scanner s = new Scanner(System.in);
        System.out.println("satir");
        a=s.nextInt();
        System.out.println("sutun");
        b=s.nextInt();
        System.out.println("karakter");
        karakter=s.next().charAt(0);
        for(int i=0;i<a;i++)
        {
            for(int j=0;j<b;j++)
            {
                if(i==0 || i==a-1 || j==0 || j==b-1)
                {
                    System.out.print(karakter);
                }
                else
                {
                    System.out.print(" ");
                }
            }
            System.out.println();
        }
    }
    
}
