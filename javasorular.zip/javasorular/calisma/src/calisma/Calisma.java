/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package calisma;
import java.util.Scanner;
/**
 *
 * @author Tuğbanur
 */
public class Calisma {

    
    public static void main(String[] args) 
    { 
        int sayi,satir,deger;
        Scanner s = new Scanner(System.in);
        System.out.println("Dizi boyutunu gir");
        sayi=s.nextInt();
        int dizi [] = new int [sayi+1];
        dizi[dizi.length-1]=9; //????
        System.out.println(sayi+"tane sayı giriniz");
        for(int a=0;a<=dizi.length-2;a++)
        {
           dizi[a]=s.nextInt();
        }
        System.out.println("Yeni sayı girilecek satır");
        satir=s.nextInt();
        System.out.println("Yeni değer");
        deger=s.nextInt();
        System.out.println();
       
        if(satir==dizi[dizi.length-1])
        {
            dizi[dizi.length-1]=deger;
        }
        else
        {
            dizi[dizi.length-1]=dizi[satir];
            dizi[satir]=deger;
        }
        for(int i=0;i<dizi.length-1;i++)
        {
            System.out.println(dizi[i]);
        }
    }
    
 
}
 

