/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hesap;

import java.util.Scanner;

/**
 *
 * @author Tuğbanur
 */
public class Hesap  {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
    sekil t1=new sekil();
    sekil t2=new sekil();
    Scanner s = new Scanner(System.in);
    System.out.println("en?");
    t1.en=s.nextInt();
    System.out.println("boy?");
    t1.boy=s.nextInt();
    if(t1.en==t1.boy)
    {
        t1.kare();
    }
    else
    {
        t1.dortgen();
    }
    System.out.println("t1 bilgisi:"+ t1.alan());
    t1.alan();
    System.out.println("en?");
    t2.en=s.nextInt();
    System.out.println("boy?");
    t2.boy=s.nextInt();
    if(t2.en>t2.boy)
    {
        t2.dortgen();
    }
    else
    {
        t2.cokgen();
    }
    System.out.println("t2 bilgisi:"+ t2.alan());
   
    }
    
}
