/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package faktoriyel;

/**
 *
 * @author Tuğbanur
 */
public class fakt  {
    static int fakt(int i)
    {
        if(i<=1) return (1);
        else
            return (i*fakt(i-1));
    }
}
