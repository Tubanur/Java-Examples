/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package c4;
import java.util.Scanner;
/**
 *
 * @author Tuğbanur
 */
public class C4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
        int sayi,basamak;
        int bosluk=5;
        Scanner s=new Scanner(System.in);
        System.out.println("basamak sayısı gir");
        basamak=s.nextInt();
        for(int i=1; i<=basamak; i++)
        {
            
            for(int a=0; a<bosluk-5;a++)
                {
                    System.out.print(" ");
                } 
            
                for(int a=0; a<5;a++)
                    {
                        System.out.print("_");
                    }
                System.out.print(i);
                System.out.println();
                
             for(int c=0; c<2; c++)
            {
                for(int a=0; a<bosluk;a++)
                {
                    System.out.print(" ");
                }
                System.out.println("|");
            }
            bosluk=bosluk+5;
            } 
        }
    }
    

