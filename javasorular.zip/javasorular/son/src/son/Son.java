/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package son;
import java.util.Scanner;
/**
 *
 * @author Tuğbanur
 */
public class Son {
    static int asal(int i)
    {
        if(i%i==0)
            return (asal(i));
        else
            return (0);
    }

    
    public static void main(String[] args) 
    {
        
        for(int i=1;i<99;i++)
        {
        System.out.print(asal(i)+" ");
        }
    }

}
