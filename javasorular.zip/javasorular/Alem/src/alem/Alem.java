/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package alem;

/**
 *
 * @author Tuğbanur
 */
public class Alem {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
       Kedi Tekir = new Kedi();
       Tekir.beslenme();
       Hayvan a[]=new Hayvan[3];
       a[0]=new Kedi();
       a[1]=new Köpek();
       a[2]=new İnek();
       for(int i=0;i<3;i++)
       {
           a[i].konusma();
       }
    }
    
}
