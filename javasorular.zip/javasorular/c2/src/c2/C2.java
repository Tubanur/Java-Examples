/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package c2;

/**
 *
 * @author Tuğbanur
 */
public class C2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
        for(int i=0; i<11; i++)
        {
            System.out.print("7");
        }
        System.out.println();
        
            for(int j=8; j>=0;j--)
            {
                
                for (int a=j; a>=0;a-- )
                {
                    System.out.print(" ");
                    
                }
                
                System.out.println("7");
            }
            
            
        
        
    }   
    
}
